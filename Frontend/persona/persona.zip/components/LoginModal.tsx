// import { useState } from 'react';
import style from '../styles/Modal.module.scss';
import { useRecoilState } from 'recoil';
import { modal } from '../states/loginState';

const API_BASE_URL = 'j8b301.p.ssafy.io:8080';

export default function Modal() {
  const [showModal, setShowModal] = useRecoilState(modal);
  // const [loading, setLoading] = useState(false);

  const shutModal = () => {
    setShowModal(false);
  };

  const handleSocialLogin = async (provider: string) => {
    // setLoading(true);
    const redirectUri = `${API_BASE_URL}/oauth2/callback/${provider}`;
    const url = `${API_BASE_URL}/oauth2/authorization/${provider}?redirect_uri=${redirectUri}`;

    try {
      const response = await fetch(url);
      if (response.ok) {
        const { data } = await response.json();
        console.log(data);
      } else {
        console.error(response.statusText);
      }
    } catch (error) {
      console.error(error);
    }

    // setLoading(false);
    shutModal();
  };

  return (
    <>
      {showModal && (
        <div className={style.back} onClick={shutModal}>
          <div className={style.container}>
            <div className={style.banner}>로그인 고르셈</div>
            <div className={style.loginSelect}>
              <img
                src="Modal_google.png"
                alt="구글로그인버튼"
                className={style.google}
                onClick={() => handleSocialLogin('google')}
                width="300"
              />
              <img
                src="Modal_naver.png"
                alt="네이버로그인버튼"
                className={style.naver}
                onClick={() => handleSocialLogin('naver')}
                width="300"
              />
              <img
                src="Modal_kakao.png"
                alt="카카오로그인버튼"
                className={style.kakao}
                onClick={() => handleSocialLogin('kakao')}
                width="300"
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
