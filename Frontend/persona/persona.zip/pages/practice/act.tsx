export default function act() {
  return (
    <>
      <div>이곳은 연기 연습 페이지입니다</div>
    </>
  );
}
