import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function comment() {
  return (
    <>
      <Header></Header>
      <div>이곳은 내가 쓴 댓글 관리 페이지입니다</div>
      <Footer></Footer>
    </>
  );
}
