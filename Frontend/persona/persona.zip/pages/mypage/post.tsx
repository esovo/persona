import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function post() {
  return (
    <>
      <Header></Header>
      <div>이곳은 내가 쓴 글 관리 페이지입니다</div>
      <Footer></Footer>
    </>
  );
}
