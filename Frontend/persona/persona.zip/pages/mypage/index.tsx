import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function info() {
  return (
    <>
      <Header></Header>
      <div>이곳은 개인 정보 관리 페이지입니다</div>
      <Footer></Footer>
    </>
  );
}
